import {platformBrowserDynamic} from '@angular/platform-browser-dynamic'
import {EventsAppModule} from './eventsapp.module'

platformBrowserDynamic().bootstrapModule(EventsAppModule)