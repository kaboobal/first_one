import {Routes} from '@angular/router'
import {EventListComponent} from './event/eventlist.component'
import {EventDetailsComponent} from './event/eventdetails.component'
import {CreateEventComponent} from './event/createevent.component'
import {Error404Component} from './errors/404.component'
import{EventRouteActivator} from './Shared/eventrouteact.service'

export const appRoutes:Routes=[

    {path:'events/new',component:CreateEventComponent},
     {path:'events',component:EventListComponent},
     {path:'events/:id',component:EventDetailsComponent,canActivate:[EventRouteActivator]},
     {path:'404',component:Error404Component},
    {path:'',redirectTo:'/events',pathMatch:'full'},
    {path:'user',loadChildren:'app/user/user.module#UserModule'}
]