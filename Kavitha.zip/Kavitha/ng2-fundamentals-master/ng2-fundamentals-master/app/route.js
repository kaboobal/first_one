"use strict";
var eventlist_component_1 = require('./event/eventlist.component');
var eventdetails_component_1 = require('./event/eventdetails.component');
var createevent_component_1 = require('./event/createevent.component');
var _404_component_1 = require('./errors/404.component');
var eventrouteact_service_1 = require('./Shared/eventrouteact.service');
exports.appRoutes = [
    { path: 'events/new', component: createevent_component_1.CreateEventComponent },
    { path: 'events', component: eventlist_component_1.EventListComponent },
    { path: 'events/:id', component: eventdetails_component_1.EventDetailsComponent, canActivate: [eventrouteact_service_1.EventRouteActivator] },
    { path: '404', component: _404_component_1.Error404Component },
    { path: '', redirectTo: '/events', pathMatch: 'full' },
    { path: 'user', loadChildren: 'app/user/user.module#UserModule' }
];
//# sourceMappingURL=route.js.map