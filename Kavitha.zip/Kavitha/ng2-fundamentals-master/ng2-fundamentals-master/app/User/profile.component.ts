import {Component} from '@angular/core'
import{FormGroup,FormControl,Validators} from '@angular/forms'
import{AuthService} from '../Shared/auth.service'
@Component({
    templateUrl:'app/user/profile.html',
    styles:[
        `
        em{float:right;color:red}
        `
    ]
   
})
    
    export class ProfileComponent{
        profileForm:FormGroup
        firstName:FormControl
        lastName:FormControl

       constructor(private authService:AuthService){

       }

        ngOnInit(){
            this.firstName=new FormControl(this.authService.currentUser.firstName, 
            [Validators.required,Validators.pattern('[a-zA-Z].*')])
             this.lastName=new FormControl(this.authService.currentUser.lastName, Validators.required)
             this.profileForm=new FormGroup({
                 firstName:this.firstName,
                 lastName:this.lastName

             })
        }

    saveProfile(formValues){
        this.authService.updateCurrentUser(formValues.firstName, formValues.lastName)
    }

    validateFirstName(){
        return this.firstName.valid || this.firstName.untouched
    }

validateLastName(){
        return this.lastName.valid || this.lastName.untouched
    }

        }

