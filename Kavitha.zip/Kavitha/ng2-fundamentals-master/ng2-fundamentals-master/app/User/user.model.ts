export interface IUser{
    firstName:string,
    id:number,
    lastName:string,
    userName:string
}