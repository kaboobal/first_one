import {Component,Input,Output,EventEmitter} from "@angular/core"
import {IEvent} from '../shared/event.model'

@Component({
    selector:'event-thumbnail',
    template:
    `
    <div [routerLink]="['/events',event.id]" class="well hoverwell thumbnail">
       <h2>{{event?.name|uppercase}}</h2>
        <div>Date:{{event?.date|date:'y/M/d'}}</div>

        <div>
        Time:{{event?.time}}
        <div [ngStyle]="getstartstyle()" [ngSwitch]="event?.time">
            <div *ngSwitchCase="'8:00 am'">[Earlystart]</div>
            <div *ngSwitchCase="'9:00 am'">[Regularstart]</div>
            <div *ngSwitchDefault>[LateStart]</div>
        </div>

       <div>Price:{{event?.price|currency:'USD':true}}</div>
     <div *ngIf="event?.location">
      <span>Location:{{event?.location?.address}}</span>
     <span>{{event?.location?.city}},{{event?.location?.country}}</span>
    </div>

    <div *ngIf="event?.onlineurl">
    onlineurl:{{event?.onlineurl}}
    </div>

    </div>
   

    `,
    styles:[
            `
            .changefont{font-style:italic; color:red}
            .changecolor{color:green}
            .thumbnail{min-height:210px}
            h2{color:red}
            
            `

    ]
})




export class EventThumbnailComponent{

@Input() event: IEvent

@Output() eventclick=new EventEmitter()

getstarttimeclass(){

    if (this.event.time==='10:00 am'){
        return ['changefont']
    }
    else{
        return['changecolor']
    }
}


getstartstyle(){

    if(this.event.time==='8:00 am')
    {
        return{'font-weight':'bold',color:'green'}
    }
    else{
        return{}
    }
}

}