import {Component} from '@angular/core'
import {EventService} from '../Shared/event.service'
import {ActivatedRoute} from '@angular/router'

@Component({

    templateUrl:'app/event/eventdetails.html',
    styles:[
        `
        .event-image{height:200px}
        `
    ]


})
export class EventDetailsComponent{
    event:any

    constructor(private eventService:EventService,
    private actroute:ActivatedRoute){

       this.event=eventService.getEvent(+this.actroute.snapshot.params['id'])

    }

}