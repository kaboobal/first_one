import {Component} from '@angular/core'
import {Router} from '@angular/router'

@Component({

    template: 
    `
    <h1>Newevent</h1>
    <hr/>
    <div>
        <h3>[Event form goes here]</h3>
        <button type="submit">Save</button>
        <button type="button" (click)="cancelme()">Cancel</button>
    </div>
    `
})


export class CreateEventComponent{

    constructor(private router:Router){

    }
    cancelme(){
        this.router.navigate(['/events'])
    }

}