import {NgModule} from '@angular/core'
import {BrowserModule} from '@angular/platform-browser'
import {RouterModule} from '@angular/router'

import {EventsAppComponent} from './eventsapp.component'

import {EventListComponent,EventThumbnailComponent,
       EventDetailsComponent,CreateEventComponent,
       SessionListComponent,DurationPipe} from './event/index'

import{EventRouteActivator,EventService,AuthService} from './Shared/index'


import {NavBarComponent} from './nav/navbar.component'
import {appRoutes} from './route'
import {Error404Component} from "./errors/404.component"


@NgModule({
imports:[
    BrowserModule,RouterModule.forRoot(appRoutes)
    
],
declarations:[
    EventsAppComponent,EventListComponent,
    EventThumbnailComponent,NavBarComponent,
    EventDetailsComponent,CreateEventComponent,
    Error404Component,SessionListComponent,DurationPipe

],

providers:[EventService ,EventRouteActivator,AuthService],

bootstrap:[
    EventsAppComponent

]

})
export class EventsAppModule{

}