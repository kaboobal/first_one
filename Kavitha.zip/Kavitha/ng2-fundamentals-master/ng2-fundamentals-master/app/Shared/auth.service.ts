import {Injectable} from '@angular/core'
import {IUser} from '../user/user.model'

@Injectable()

export class AuthService{

    currentUser:IUser

    authenticateUser(userName:string,password:string){
        //code to hit the restful server
        this.currentUser={
            id:1,
            firstName:'Shirish',
            lastName:'Agarwal',
            userName:userName
        }


    }

    updateCurrentUser(firstName:string,lastName:string){
        this.currentUser.firstName=firstName
        this.currentUser.lastName=lastName
        //code for restful
    }

    isAuthenticated(){
        return !!this.currentUser
    }

}